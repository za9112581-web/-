import 'package:flutter/material.dart';
import 'screens/welcome_screen.dart';

void main() => runApp(const DataApp());

class DataApp extends StatelessWidget {
  const DataApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.green, useMaterial3: true),
      home: const WelcomeScreen(),
    );
  }
}
