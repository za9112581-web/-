import 'package:flutter/material.dart';
import 'product_detail_screen.dart';

class ProductListScreen extends StatelessWidget {
  const ProductListScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final products = ['MacBook', 'iPhone', 'iPad', 'iWatch'];
    return Scaffold(
      appBar: AppBar(title: const Text('Products')),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, i) => ListTile(
          title: Text(products[i]),
          trailing: const Icon(Icons.arrow_forward_ios),
          onTap: () async {
            final result = await Navigator.push(
              context,
              MaterialPageRoute(builder: (c) => ProductDetailScreen(productName: products[i])),
            );
            if (context.mounted && result != null) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result)));
            }
          },
        ),
      ),
    );
  }
}
